#!/system/bin/sh
# Game Mode daemon: while a toggled game is in the foreground, silence all notifications.
DATA=/data/adb/notif_blocker
LIST=$DATA/games.list
STATE=$DATA/gm.state
PIDF=$DATA/gamed.pid

mkdir -p "$DATA" 2>/dev/null
[ -f "$LIST" ] || : > "$LIST"

# single instance
if [ -f "$PIDF" ]; then
  old=$(cat "$PIDF" 2>/dev/null)
  [ -n "$old" ] && [ "$old" != "$$" ] && kill -0 "$old" 2>/dev/null && exit 0
fi
echo $$ > "$PIDF"

fg() {
  p=$(dumpsys activity activities 2>/dev/null | grep -m1 "ResumedActivity" | sed -n 's/.* \([A-Za-z0-9._]*\)\/.*/\1/p')
  [ -z "$p" ] && p=$(dumpsys window 2>/dev/null | grep -m1 "mCurrentFocus" | sed -n 's/.* \([A-Za-z0-9._]*\)\/.*/\1/p')
  echo "$p"
}

enter() {
  [ -f "$STATE" ] && return
  z=$(settings get global zen_mode 2>/dev/null)
  h=$(settings get global heads_up_notifications_enabled 2>/dev/null)
  printf 'zen=%s\nheads=%s\n' "$z" "$h" > "$STATE"
  settings put global heads_up_notifications_enabled 0 >/dev/null 2>&1
  cmd notification set_dnd alarms >/dev/null 2>&1
}

leave() {
  [ -f "$STATE" ] || return
  zen=0; heads=1
  . "$STATE"
  case "$zen" in
    1) m=priority ;;
    2) m=none ;;
    3) m=alarms ;;
    *) m=off ;;
  esac
  cmd notification set_dnd "$m" >/dev/null 2>&1
  if [ "$heads" = "null" ] || [ -z "$heads" ]; then
    settings delete global heads_up_notifications_enabled >/dev/null 2>&1
  else
    settings put global heads_up_notifications_enabled "$heads" >/dev/null 2>&1
  fi
  rm -f "$STATE"
}

trap 'leave; rm -f "$PIDF"; exit 0' TERM INT

# if a previous run died while a game was active, restore first
leave

while true; do
  if [ -f "$DATA/gm.disabled" ] || [ ! -s "$LIST" ]; then
    leave
    sleep 5
    continue
  fi
  p=$(fg)
  case "$p" in
    ""|com.android.systemui) ;;   # transient (shade/recents): keep current state
    *)
      if grep -qx "$p" "$LIST" 2>/dev/null; then enter; else leave; fi
      ;;
  esac
  sleep 3
done
