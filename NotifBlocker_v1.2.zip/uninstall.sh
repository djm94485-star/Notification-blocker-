#!/system/bin/sh
# Restore notifications for every app we blocked, then clean up
MODDIR=${0%/*}
# stop Game Mode daemon and restore notification state
if [ -f /data/adb/notif_blocker/gamed.pid ]; then
  kill "$(cat /data/adb/notif_blocker/gamed.pid)" 2>/dev/null
  sleep 1
fi
sh "$MODDIR/blocker.sh" unblock-all >/dev/null 2>&1
rm -rf /data/adb/notif_blocker
