#!/system/bin/sh
# Notification Blocker core script (runs as root)
# Usage: blocker.sh <list|block|unblock|apply|unblock-all|check> [pkg]

DATA=/data/adb/notif_blocker
LIST=$DATA/blocked.list
UID_USER=0
PERM=android.permission.POST_NOTIFICATIONS
MODDIR=${0%/*}
GLIST=$DATA/games.list
GMAN=$DATA/games.manual
GCACHE=$DATA/game.cache
STATE=$DATA/gm.state
PIDF=$DATA/gamed.pid

mkdir -p "$DATA" 2>/dev/null
[ -f "$LIST" ] || : > "$LIST"
[ -f "$GLIST" ] || : > "$GLIST"
[ -f "$GMAN" ] || : > "$GMAN"

valid() {
  case "$1" in
    ""|*[!A-Za-z0-9._]*) return 1 ;;
  esac
  return 0
}

do_block() {
  p="$1"
  appops set --user $UID_USER "$p" POST_NOTIFICATION deny >/dev/null 2>&1 \
    || cmd appops set --user $UID_USER "$p" POST_NOTIFICATION deny >/dev/null 2>&1
  pm revoke --user $UID_USER "$p" $PERM >/dev/null 2>&1
  grep -qx "$p" "$LIST" || echo "$p" >> "$LIST"
}

do_unblock() {
  p="$1"
  appops set --user $UID_USER "$p" POST_NOTIFICATION default >/dev/null 2>&1 \
    || cmd appops set --user $UID_USER "$p" POST_NOTIFICATION default >/dev/null 2>&1
  pm grant --user $UID_USER "$p" $PERM >/dev/null 2>&1
  grep -vx "$p" "$LIST" > "$LIST.tmp" 2>/dev/null
  mv "$LIST.tmp" "$LIST"
}

gm_running() {
  [ -f "$PIDF" ] && kill -0 "$(cat "$PIDF" 2>/dev/null)" 2>/dev/null
}

# heuristic game detection (cached)
detect_game() {
  case "$1" in
    *game*|com.tencent.ig|com.tencent.tmgp.*|com.pubg*|com.garena*|com.dts.freefire*|com.activision.*|com.mojang*|com.supercell*|com.miHoYo*|com.mihoyo*|com.HoYoverse*|com.mobile.legends|com.moonton*|com.roblox*|com.epicgames*|com.netease*|com.riotgames*|com.gameloft*|com.ea.*|com.ubisoft*|com.konami*|com.squareenix*|com.bandainamco*|com.krafton*|com.levelinfinite*|com.miniclip*|com.playrix*)
      return 0 ;;
  esac
  dumpsys package "$1" 2>/dev/null | grep -qE "(^|[[:space:]])(category=0|IS_GAME)([[:space:]]|\]|$)"
}
is_game() {
  c=$(grep -m1 "^$1 " "$GCACHE" 2>/dev/null)
  if [ -n "$c" ]; then [ "${c#* }" = 1 ]; return; fi
  if detect_game "$1"; then echo "$1 1" >> "$GCACHE"; return 0; fi
  echo "$1 0" >> "$GCACHE"; return 1
}
list_rm() { # file pkg
  grep -vx "$2" "$1" > "$1.tmp" 2>/dev/null
  mv "$1.tmp" "$1"
}

cmd="$1"
pkg="$2"

case "$cmd" in
  list)
    BL=" $(tr '\n' ' ' < "$LIST") "
    emit() {
      # $1 = S flag
      while read -r line; do
        p="${line#package:}"
        [ -z "$p" ] && continue
        b=0
        case "$BL" in *" $p "*) b=1 ;; esac
        echo "$p|$1|$b"
      done
    }
    pm list packages -3 --user $UID_USER 2>/dev/null | emit 0
    pm list packages -s --user $UID_USER 2>/dev/null | emit 1
    ;;
  block)
    valid "$pkg" || { echo "ERR invalid package"; exit 1; }
    do_block "$pkg"
    echo "OK"
    ;;
  unblock)
    valid "$pkg" || { echo "ERR invalid package"; exit 1; }
    do_unblock "$pkg"
    echo "OK"
    ;;
  apply)
    while read -r p; do
      valid "$p" && do_block "$p"
    done < "$LIST"
    echo "OK"
    ;;
  unblock-all)
    cp "$LIST" "$LIST.old" 2>/dev/null
    while read -r p; do
      valid "$p" && do_unblock "$p"
    done < "$LIST.old"
    : > "$LIST"
    rm -f "$LIST.old"
    echo "OK"
    ;;
  check)
    valid "$pkg" || { echo "ERR invalid package"; exit 1; }
    appops get --user $UID_USER "$pkg" POST_NOTIFICATION 2>&1
    ;;
  games)
    EN=" $(tr '\n' ' ' < "$GLIST") "
    MAN=" $(tr '\n' ' ' < "$GMAN") "
    for p in $(pm list packages -3 --user $UID_USER 2>/dev/null | sed 's/^package://'); do
      valid "$p" || continue
      case "$MAN" in *" $p "*) continue ;; esac
      if is_game "$p"; then
        e=0; case "$EN" in *" $p "*) e=1 ;; esac
        echo "$p|a|$e"
      fi
    done
    while read -r p; do
      valid "$p" || continue
      e=0; case "$EN" in *" $p "*) e=1 ;; esac
      echo "$p|m|$e"
    done < "$GMAN"
    ;;
  games-rescan)
    rm -f "$GCACHE"
    echo "OK"
    ;;
  game-on)
    valid "$pkg" || { echo "ERR invalid package"; exit 1; }
    grep -qx "$pkg" "$GLIST" || echo "$pkg" >> "$GLIST"
    echo "OK"
    ;;
  game-off)
    valid "$pkg" || { echo "ERR invalid package"; exit 1; }
    list_rm "$GLIST" "$pkg"
    echo "OK"
    ;;
  game-add)
    valid "$pkg" || { echo "ERR invalid package"; exit 1; }
    grep -qx "$pkg" "$GMAN" || echo "$pkg" >> "$GMAN"
    grep -qx "$pkg" "$GLIST" || echo "$pkg" >> "$GLIST"
    echo "OK"
    ;;
  game-del)
    valid "$pkg" || { echo "ERR invalid package"; exit 1; }
    list_rm "$GMAN" "$pkg"
    list_rm "$GLIST" "$pkg"
    echo "OK"
    ;;
  gm-master)
    case "$pkg" in
      on)  rm -f "$DATA/gm.disabled" ;;
      off) : > "$DATA/gm.disabled" ;;
      *)   echo "ERR"; exit 1 ;;
    esac
    echo "OK"
    ;;
  gm-start)
    gm_running || (nohup sh "$MODDIR/gamed.sh" >/dev/null 2>&1 </dev/null &)
    echo "OK"
    ;;
  gm-status)
    [ -f "$DATA/gm.disabled" ] && echo "master=off" || echo "master=on"
    gm_running && echo "daemon=running" || echo "daemon=stopped"
    [ -f "$STATE" ] && echo "active=1" || echo "active=0"
    ;;
  *)
    echo "usage: $0 list|block|unblock|apply|unblock-all|check [pkg]"
    exit 1
    ;;
esac
