#!/system/bin/sh
# Re-apply the block list after every boot
MODDIR=${0%/*}

until [ "$(getprop sys.boot_completed)" = "1" ]; do
  sleep 5
done
sleep 20

sh "$MODDIR/blocker.sh" apply >/dev/null 2>&1

# Game Mode daemon (v1.2)
nohup sh "$MODDIR/gamed.sh" >/dev/null 2>&1 </dev/null &
