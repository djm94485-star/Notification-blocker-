#!/system/bin/sh
SKIPUNZIP=0

ui_print "- Notification Blocker v1.2 (by shahadat)"
ui_print "- New: Game Mode, Settings, custom header, Monet theme"
ui_print "- Open the module's WebUI from KernelSU manager"

set_perm_recursive "$MODPATH" 0 0 0755 0644
set_perm "$MODPATH/blocker.sh" 0 0 0755
set_perm "$MODPATH/service.sh" 0 0 0755
set_perm "$MODPATH/uninstall.sh" 0 0 0755
set_perm "$MODPATH/gamed.sh" 0 0 0755

mkdir -p /data/adb/notif_blocker
[ -f /data/adb/notif_blocker/blocked.list ] || : > /data/adb/notif_blocker/blocked.list
[ -f /data/adb/notif_blocker/games.list ] || : > /data/adb/notif_blocker/games.list
[ -f /data/adb/notif_blocker/games.manual ] || : > /data/adb/notif_blocker/games.manual
