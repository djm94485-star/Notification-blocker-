#!/system/bin/sh
# Restore every app notification setting when the module is removed
sh /data/adb/modules/notif_blocker/nb.sh run_off
rm -rf /data/adb/notif_blocker
