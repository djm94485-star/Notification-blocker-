D=/data/adb/notif_blocker
mkdir -p $D
[ -f $D/exclude.txt ] || cp $MODPATH/exclude.default $D/exclude.txt
set_perm_recursive $MODPATH 0 0 0755 0644
set_perm $MODPATH/nb.sh 0 0 0755
set_perm $MODPATH/action.sh 0 0 0755
set_perm $MODPATH/service.sh 0 0 0755
set_perm $MODPATH/uninstall.sh 0 0 0755
ui_print "- Open the module WebUI from the KernelSU module list to toggle"
ui_print "- Protected apps are listed in /data/adb/notif_blocker/exclude.txt"
