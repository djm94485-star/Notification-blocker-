#!/system/bin/sh
# Notification Blocker core script. Usage: nb.sh on | off | status | toggle
D=${NB_DIR:-/data/adb/notif_blocker}
M=${NB_MOD:-/data/adb/modules/notif_blocker}
STATE=$D/state
SNAP=$D/snapshot.txt
EXC=$D/exclude.txt
CLEAN=$D/exclude.clean
PROG=$D/progress
LOCK=$D/lock
OP=POST_NOTIFICATION
mkdir -p "$D"
[ -f "$EXC" ] || cp "$M/exclude.default" "$EXC" 2>/dev/null
[ -f "$STATE" ] || echo off > "$STATE"

list_pkgs() { pm list packages --user 0 2>/dev/null | cut -d: -f2; }

busy() {
  [ -f "$LOCK" ] || return 1
  pid=$(cat "$LOCK" 2>/dev/null)
  [ -n "$pid" ] && [ -d "/proc/$pid" ]
}

do_on() {
  busy && exit 0
  echo $$ > "$LOCK"
  echo on > "$STATE"
  grep -vE '^[[:space:]]*(#|$)' "$EXC" > "$CLEAN" 2>/dev/null
  touch "$SNAP"
  total=$(list_pkgs | wc -l)
  i=0
  for p in $(list_pkgs); do
    i=$((i+1))
    echo "$i/$total" > "$PROG"
    grep -qxF "$p" "$CLEAN" && continue
    grep -q "^$p " "$SNAP" && continue
    raw=$(cmd appops get --user 0 "$p" $OP 2>/dev/null)
    mode=$(echo "$raw" | grep -o "$OP: [a-z]*" | head -1 | cut -d' ' -f2)
    echo "$p $mode" >> "$SNAP"
    cmd appops set --user 0 "$p" $OP deny >/dev/null 2>&1
  done
  echo done > "$PROG"
  rm -f "$LOCK"
}

do_off() {
  busy && exit 0
  echo $$ > "$LOCK"
  echo off > "$STATE"
  if [ -f "$SNAP" ]; then
    total=$(wc -l < "$SNAP")
    i=0
    while read -r p mode; do
      i=$((i+1))
      echo "$i/$total" > "$PROG"
      case "$mode" in
        ignore|deny|foreground) m=$mode ;;
        *) m=default ;;
      esac
      cmd appops set --user 0 "$p" $OP $m >/dev/null 2>&1
    done < "$SNAP"
    rm -f "$SNAP"
  fi
  echo done > "$PROG"
  rm -f "$LOCK"
}

status() {
  s=$(cat "$STATE" 2>/dev/null)
  pr=$(cat "$PROG" 2>/dev/null)
  c=0; [ -f "$SNAP" ] && c=$(wc -l < "$SNAP")
  b=0; busy && b=1
  echo "state=$s;progress=$pr;count=$c;busy=$b"
}

case "$1" in
  on)  nohup sh "$0" run_on  >/dev/null 2>&1 & echo started ;;
  off) nohup sh "$0" run_off >/dev/null 2>&1 & echo started ;;
  run_on)  do_on ;;
  run_off) do_off ;;
  toggle)
    if [ "$(cat "$STATE")" = "on" ]; then sh "$0" off; else sh "$0" on; fi ;;
  status) status ;;
  *) echo "usage: nb.sh on|off|toggle|status" ;;
esac
