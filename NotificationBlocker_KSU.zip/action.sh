#!/system/bin/sh
sh /data/adb/modules/notif_blocker/nb.sh toggle >/dev/null
sleep 1
if [ "$(cat /data/adb/notif_blocker/state 2>/dev/null)" = "on" ]; then
  echo "Notifications: BLOCKED (applying to all apps, takes a minute)"
else
  echo "Notifications: ALLOWED (restoring app settings)"
fi
