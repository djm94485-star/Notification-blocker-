#!/system/bin/sh
# Re-apply after boot if blocking was on (also catches newly installed apps)
until [ "$(getprop sys.boot_completed)" = "1" ]; do sleep 5; done
sleep 30
D=/data/adb/notif_blocker
[ "$(cat $D/state 2>/dev/null)" = "on" ] && sh /data/adb/modules/notif_blocker/nb.sh on
